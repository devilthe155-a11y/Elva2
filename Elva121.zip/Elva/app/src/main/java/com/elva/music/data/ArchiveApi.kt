package com.elva.music.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request

/** Internet Archive audio: public-domain and openly shared recordings. No API key needed. */
object ArchiveApi {
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    private fun get(url: okhttp3.HttpUrl): JsonObject =
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            json.parseToJsonElement(r.body!!.string()).jsonObject
        }

    private fun JsonElement?.firstText(): String = when (this) {
        is JsonArray -> firstOrNull()?.jsonPrimitive?.contentOrNull ?: ""
        is JsonPrimitive -> contentOrNull ?: ""
        else -> ""
    }

    suspend fun search(query: String, limit: Int = 10): List<Track> = withContext(Dispatchers.IO) {
        val words = query.replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim()
        if (words.isBlank()) return@withContext emptyList()
        val url = "https://archive.org/advancedsearch.php".toHttpUrl().newBuilder()
            .addQueryParameter("q", "(title:($words) OR creator:($words)) AND mediatype:(audio)")
            .addQueryParameter("fl[]", "identifier").addQueryParameter("fl[]", "title").addQueryParameter("fl[]", "creator")
            .addQueryParameter("sort[]", "downloads desc")
            .addQueryParameter("rows", limit.toString())
            .addQueryParameter("output", "json").build()
        val docs = get(url)["response"]?.jsonObject?.get("docs")?.jsonArray ?: return@withContext emptyList()
        coroutineScope {
            docs.map { d ->
                async {
                    runCatching {
                        val o = d.jsonObject
                        val id = o["identifier"]!!.jsonPrimitive.content
                        val meta = get("https://archive.org/metadata/$id".toHttpUrl())
                        val file = meta["files"]?.jsonArray?.map { it.jsonObject }?.firstOrNull {
                            val n = it["name"]?.jsonPrimitive?.contentOrNull ?: ""
                            n.endsWith(".mp3", true) && !n.contains("_sample", true)
                        } ?: return@runCatching null
                        val name = file["name"]!!.jsonPrimitive.content
                        val audio = "https://archive.org/download/".toHttpUrl().newBuilder()
                            .addPathSegment(id).addPathSegments(name).build().toString()
                        Track(
                            id = "ia:$id",
                            name = o["title"].firstText().ifBlank { id },
                            artist_name = o["creator"].firstText(),
                            image = "https://archive.org/services/img/$id",
                            audio = audio,
                            duration = file["length"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()?.toInt() ?: 0,
                            source = "Internet Archive",
                        )
                    }.getOrNull()
                }
            }.awaitAll().filterNotNull()
        }
    }
}
