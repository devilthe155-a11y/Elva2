# Elva

An original, ad-free music player for Android (Kotlin + Jetpack Compose + Media3).
Searches Audius and the Internet Archive together. No account, API key or ads.

## Build
Open this folder in Android Studio (Koala or newer), let Gradle sync, press Run.
Or: `gradle wrapper && ./gradlew assembleDebug`. APK lands in app/build/outputs/apk/debug/.

## Features
Home shelves (trending + genres), search, liked songs, playlists, mini and full player,
shuffle/repeat, background playback with notification and lock-screen controls.
